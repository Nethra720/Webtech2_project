<?php session_start();
$_SESSION["number"]=$_POST["number"];
$_SESSION["username"]=$_POST["username"];
?>