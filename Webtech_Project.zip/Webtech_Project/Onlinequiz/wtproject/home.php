<?php session_start();?>
<!DOCTYPE html>
<html>
<head>
	<title>HOME</title>
</head>
<body>
	
	<a href="profile.html">Profile</a>
	<a href="quizcatalog.html">Quiz Catalog</a>
	<a href="quizDetails.html">New Quiz</a>
	<a href="getmyquiz.html">My Quizzes</a>
	<a href="home.php">Play Quiz</a>
	
	<input type="text" name="">
	<button onclick="obj.getQuiz()">Start Quiz</button>
	<a href="logout.php">Logout</a>
</body>
<script type="text/javascript">
	var obj={
		getQuiz:function()
		{
			inputs=document.getElementsByTagName("input");
			number=inputs[0].value;
			localStorage.setItem("number",number);
			window.location.href="quiz.html";
		}
	}
</script>
</html>